let total = 0;

function addToCart(itemName, price) {
    const cartItems = document.getElementById("cart-items");
    const li = document.createElement("li");
    li.textContent = `${itemName} - ₹${price}`;
    cartItems.appendChild(li);

    total += price;
    document.getElementById("total").textContent = total;
}
