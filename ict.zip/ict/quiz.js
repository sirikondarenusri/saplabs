const quizData = [
    {
        question: "Which language is used for web development?",
        a: "Python",
        b: "HTML",
        c: "C",
        d: "Java",
        correct: "b"
    },
    {
        question: "Which tag is used for JavaScript?",
        a: "<js>",
        b: "<javascript>",
        c: "<script>",
        d: "<code>",
        correct: "c"
    },
    {
        question: "CSS stands for?",
        a: "Computer Style Sheets",
        b: "Creative Style System",
        c: "Cascading Style Sheets",
        d: "Color Style Sheets",
        correct: "c"
    }
];

let currentQuiz = 0;
let score = 0;

const questionEl = document.getElementById("question");
const answersEls = document.querySelectorAll(".answer");
const a_text = document.getElementById("a_text");
const b_text = document.getElementById("b_text");
const c_text = document.getElementById("c_text");
const d_text = document.getElementById("d_text");
const submitBtn = document.getElementById("submit");

loadQuiz();

function loadQuiz() {
    deselectAnswers();

    const currentQuizData = quizData[currentQuiz];
    questionEl.innerText = currentQuizData.question;
    a_text.innerText = currentQuizData.a;
    b_text.innerText = currentQuizData.b;
    c_text.innerText = currentQuizData.c;
    d_text.innerText = currentQuizData.d;
}

function deselectAnswers() {
    answersEls.forEach(answer => answer.checked = false);
}

function getSelected() {
    let answer;
    answersEls.forEach(ans => {
        if (ans.checked) {
            answer = ans.id;
        }
    });
    return answer;
}

submitBtn.addEventListener("click", () => {
    const answer = getSelected();

    if (answer) {
        if (answer === quizData[currentQuiz].correct) {
            score++;
        }

        currentQuiz++;

        if (currentQuiz < quizData.length) {
            loadQuiz();
        } else {
            document.querySelector(".quiz-container").innerHTML = `
                <h2>You answered ${score} out of ${quizData.length} correctly</h2>
                <button onclick="location.reload()">Restart Quiz</button>
            `;
        }
    }
});
