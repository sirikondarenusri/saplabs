
let students = [];

function addStudent() {
    let name = document.getElementById("name").value;
    let marks = document.getElementById("marks").value;

    if (name === "" || marks === "") {
        alert("Please enter all details");
        return;
    }

    let grade = calculateGrade(marks);
    students.push({ name, marks, grade });

    displayStudents();
    document.getElementById("name").value = "";
    document.getElementById("marks").value = "";
}

function calculateGrade(marks) {
    if (marks >= 90) {
        return "A";
    } else if (marks >= 75) {
        return "B";
    } else if (marks >= 60) {
        return "C";
    } else if (marks >= 40) {
        return "D";
    } else {
        return "Fail";
    }
}

function displayStudents() {
    let table = document.getElementById("studentTable");
    table.innerHTML = "";

    for (let i = 0; i < students.length; i++) {
        let row = `
            <tr>
                <td>${students[i].name}</td>
                <td>${students[i].marks}</td>
                <td>${students[i].grade}</td>
            </tr>
        `;
        table.innerHTML += row;
    }
}
