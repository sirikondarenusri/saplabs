import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ReactiveFormsModule, FormBuilder, FormGroup, Validators } from '@angular/forms';

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule],
  templateUrl: './app.html',
  styleUrls: ['./app.css']
})
export class App {

  // AUTH STATES
  showLogin = true;
  isLoggedIn = false;

  loginForm: FormGroup;
  registerForm: FormGroup;

  // RESTAURANT ITEMS
  menu = [
    { id: 1, name: 'Pizza', price: 200 },
    { id: 2, name: 'Burger', price: 120 },
    { id: 3, name: 'Pasta', price: 180 },
    { id: 4, name: 'Fried Rice', price: 150 }
  ];

  cart: any[] = [];
  total = 0;

  constructor(private fb: FormBuilder) {

    this.loginForm = this.fb.group({
      email: ['', [Validators.required, Validators.email]],
      password: ['', Validators.required]
    });

    this.registerForm = this.fb.group({
      name: ['', Validators.required],
      email: ['', [Validators.required, Validators.email]],
      password: ['', Validators.required],
      confirmPassword: ['', Validators.required]
    });
  }

  toggleForm() {
    this.showLogin = !this.showLogin;
  }

  // REGISTER
  register() {
    if (this.registerForm.invalid) return;

    const { name, email, password, confirmPassword } = this.registerForm.value;

    if (password !== confirmPassword) {
      alert('Passwords do not match');
      return;
    }

    localStorage.setItem('user', JSON.stringify({ name, email, password }));
    alert('Registration successful. Please login.');
    this.showLogin = true;
  }

  // LOGIN
  login() {
    if (this.loginForm.invalid) return;

    const storedUser = localStorage.getItem('user');
    if (!storedUser) {
      alert('Please register first');
      return;
    }

    const user = JSON.parse(storedUser);
    const { email, password } = this.loginForm.value;

    if (user.email === email && user.password === password) {
      this.isLoggedIn = true;
      alert('Welcome to Restaurant!');
    } else {
      alert('Invalid credentials');
    }
  }

  logout() {
    this.isLoggedIn = false;
    this.cart = [];
    this.total = 0;
  }

  // ADD TO CART
  addToCart(item: any) {
    this.cart.push(item);
    this.calculateTotal();
  }

  // REMOVE FROM CART
  removeFromCart(index: number) {
    this.cart.splice(index, 1);
    this.calculateTotal();
  }

  calculateTotal() {
    this.total = this.cart.reduce((sum, item) => sum + item.price, 0);
  }
}
